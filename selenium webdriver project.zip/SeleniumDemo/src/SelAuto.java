import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelAuto {
	public static void main(String[] args) {
		
		//register the Chrome driver
		System.setProperty("webdriver.chrome.driver","E:\\Selenium jars\\chromedriver.exe");
		//create an obj to the driver -obj to the browser
		WebDriver wd=new ChromeDriver();//wd is the controller obj to web browser
		//maximize the screen
		wd.manage().window().maximize();
		//web URL 
		wd.get("https://www.amazon.in/");
		
	}
	}

