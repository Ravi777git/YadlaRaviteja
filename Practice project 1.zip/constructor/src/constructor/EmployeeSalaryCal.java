package constructor;

//parameteried constructor

import java.util.Scanner;

class EmployeeCalImp{
	EmployeeCalImp(int salary,int bonus) {
	 System.out.println("the updated salary is "+ (salary+bonus));	
	}
}

public class EmployeeSalaryCal{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the salary details ");
		int salary=sc.nextInt();
		System.out.println("enter the bonus details");
		int bonus=sc.nextInt();
	EmployeeCalImp calimp=new EmployeeCalImp(salary,bonus);

	}
}
