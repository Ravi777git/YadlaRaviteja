/**
 * 
 */
/**
 * @author hi
 *
 */
module constructor {
}