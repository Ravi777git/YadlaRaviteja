
package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewClass {
	
  @Test
  public void test1() {
	 WebDriverManager.chromedriver().setup();	  
	//  System.setProperty("webdriver.chrome.driver","F:\\seleniumjars\\chromedriver.exe");
	  WebDriver wd=new ChromeDriver();
	  wd.manage().window().maximize();
	  wd.get("https://www.amazon.in/");
	  wd.close();
  }
  
  
  @Test
  public void test2() {
	 System.out.println("hi"); 
  }
  
 
}
